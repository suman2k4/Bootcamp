class dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def bark(self):
        print(dog1.name,"is barking")
    def sleep(self):
        print(dog1.name,"is sleeping")
dog1=dog("aslma",20)
dog1.bark()
dog1.sleep()