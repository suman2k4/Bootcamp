class dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age
dog1=dog("aslam",20)
print(dog1.name)
print(dog1.age)